import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { isAdminEmail } from "@/lib/security/admin.server";

export const metadata: Metadata = {
  title: "Firma Electrónica Simple",
  description: "Firma electrónica simple, segura y legal en Argentina (Ley 25.506).",
};

export const dynamic = "force-dynamic";

function NavLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} className="text-sm text-zinc-700 hover:text-zinc-900">
      {children}
    </Link>
  );
}

function NavButton({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <Link href={href} className="rounded-md bg-black px-3 py-1.5 text-sm font-medium text-white">
      {children}
    </Link>
  );
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const email = (user?.email || "").toLowerCase();
  const isAdmin = Boolean(email) && isAdminEmail(email);

  return (
    <html lang="es">
      <body>
        <header className="sticky top-0 z-20 border-b border-zinc-200 bg-white/80 backdrop-blur">
          <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
            <Link href="/" className="font-semibold">
              Firma Electrónica Simple
            </Link>
            <nav className="flex items-center gap-4">
              {user ? (
                <>
                  <NavLink href="/dashboard">Dashboard</NavLink>
                  <NavLink href="/dashboard/new">Nuevo</NavLink>
                  <NavLink href="/dashboard/account">Cuentas</NavLink>
                  {isAdmin ? <NavLink href="/admin">Admin</NavLink> : null}
                  <NavLink href="/terms">Términos</NavLink>
                  <NavLink href="/privacy">Privacidad</NavLink>
                  <NavLink href="/pricing">Planes</NavLink>
                  <a
                    href="/api/logout"
                    className="rounded-md bg-black px-3 py-1.5 text-sm font-medium text-white"
                  >
                    Salir
                  </a>
                </>
              ) : (
                <>
                  <NavLink href="/pricing">Planes</NavLink>
                  <NavLink href="/terms">Términos</NavLink>
                  <NavLink href="/privacy">Privacidad</NavLink>
                  <NavButton href="/login?next=%2Fdashboard">Ingresar</NavButton>
                </>
              )}
            </nav>
          </div>
        </header>

        <main>{children}</main>

        <footer className="border-t border-zinc-200">
          <div className="mx-auto max-w-5xl px-4 py-8 text-xs text-zinc-500">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>© {new Date().getFullYear()} Firma Electrónica Simple</div>
              <div className="flex items-center gap-4">
                <Link href="/terms" className="hover:text-zinc-800">
                  Términos
                </Link>
                <Link href="/privacy" className="hover:text-zinc-800">
                  Privacidad
                </Link>
                <Link href="/pricing" className="hover:text-zinc-800">
                  Planes
                </Link>
              </div>
            </div>
            <p className="mt-3 leading-relaxed">
              Este servicio implementa firma electrónica conforme a la Ley 25.506 (República Argentina). No constituye firma digital
              certificada en los términos de la misma ley.
            </p>
          </div>
        </footer>
      </body>
    </html>
  );
}
