import { NextRequest, NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";
import { Redis } from "@upstash/redis";
import { Ratelimit } from "@upstash/ratelimit";

function requiredEnv(name: string) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

// -------- Rate limit (Edge) --------
const redis = new Redis({
  url: requiredEnv("UPSTASH_REDIS_REST_URL"),
  token: requiredEnv("UPSTASH_REDIS_REST_TOKEN"),
});

const apiRateLimit = new Ratelimit({
  redis,
  limiter: Ratelimit.slidingWindow(60, "1 m"), // 60 req/min
  analytics: true,
  prefix: "fes_api_rl",
});

function getIp(req: NextRequest) {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    req.headers.get("x-real-ip") ||
    "unknown"
  );
}

// Rutas públicas (NO requieren sesión)
function isPublicPath(pathname: string) {
  if (pathname === "/") return true;
  if (pathname.startsWith("/login")) return true;
  if (pathname.startsWith("/pricing")) return true;
  if (pathname.startsWith("/terms")) return true;
  if (pathname.startsWith("/privacy")) return true;

  if (pathname.startsWith("/auth/callback")) return true;
  if (pathname.startsWith("/auth/callback-client")) return true;

  if (pathname.startsWith("/s/")) return true;

  if (pathname.startsWith("/api/auth/magic-link")) return true;
  if (pathname.startsWith("/api/auth/set-session")) return true;

  if (pathname.startsWith("/api/signing-request")) return true;
  if (pathname.startsWith("/api/sign")) return true;
  if (pathname.startsWith("/api/reject")) return true;
  if (pathname.startsWith("/api/download")) return true;
  if (pathname.startsWith("/api/preview")) return true;

  return false;
}

// Rutas que SÍ requieren sesión
function isProtectedPath(pathname: string) {
  if (pathname.startsWith("/dashboard")) return true;
  if (pathname.startsWith("/admin")) return true;

  if (pathname.startsWith("/api/admin")) return true;
  if (pathname.startsWith("/api/documents")) return true;
  if (pathname.startsWith("/api/upload")) return true;
  if (pathname.startsWith("/api/invite")) return true;
  if (pathname.startsWith("/api/audit")) return true;
  if (pathname.startsWith("/api/resend-invite")) return true;
  if (pathname.startsWith("/api/profile")) return true;
  if (pathname.startsWith("/api/logout")) return true;

  return false;
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/favicon.ico") ||
    pathname.startsWith("/icon") ||
    pathname.startsWith("/robots.txt") ||
    pathname.startsWith("/sitemap.xml")
  ) {
    return NextResponse.next();
  }

  // ✅ Excluir resend-invite del rate limit global (para evitar 429 al testear)
  const skipRateLimit =
    pathname.startsWith("/api/resend-invite") ||
    pathname.startsWith("/api/auth"); // auth ya estaba excluido abajo, lo dejamos explícito

  if (pathname.startsWith("/api") && !skipRateLimit) {
    const ip = getIp(req);
    const { success } = await apiRateLimit.limit(`ip:${ip}`);
    if (!success) {
      return new NextResponse("Too Many Requests", { status: 429 });
    }
  }

  if (isPublicPath(pathname)) return NextResponse.next();
  if (!isProtectedPath(pathname)) return NextResponse.next();

  const res = NextResponse.next();

  type CookieOptions = Parameters<typeof res.cookies.set>[2];
  type CookieToSet = { name: string; value: string; options?: CookieOptions };

  const supabase = createServerClient(
    requiredEnv("NEXT_PUBLIC_SUPABASE_URL"),
    requiredEnv("NEXT_PUBLIC_SUPABASE_ANON_KEY"),
    {
      cookies: {
        getAll() {
          return req.cookies.getAll();
        },
        setAll(cookiesToSet: CookieToSet[]) {
          cookiesToSet.forEach(({ name, value, options }: CookieToSet) => {
            res.cookies.set(name, value, options);
          });
        },
      },
    }
  );

  const { data: { user } } = await supabase.auth.getUser();

  if (!user) {
    if (pathname.startsWith("/api")) {
      return NextResponse.json({ error: "unauthorized" }, { status: 401 });
    }

    const loginUrl = req.nextUrl.clone();
    loginUrl.pathname = "/login";
		// Preservar query para que /login pueda devolver al lugar exacto.
		loginUrl.searchParams.set("next", pathname + (req.nextUrl.search || ""));
    return NextResponse.redirect(loginUrl);
  }

  return res;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};